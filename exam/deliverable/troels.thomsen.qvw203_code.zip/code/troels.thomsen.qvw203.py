
print '\n\n' + '#' * 10 + ' Assignment 1 & 2 ' + '#' * 10 + '\n\n'

execfile('troels.thomsen.qvw203_1_2.py')

print '\n\n' + '#' * 10 + ' Assignment 3 ' + '#' * 10 + '\n\n'

execfile('troels.thomsen.qvw203_3.py')

print '\n\n' + '#' * 10 + ' Assignment 4 ' + '#' * 10 + '\n\n'

execfile('troels.thomsen.qvw203_4.py')

print '\n\n' + '#' * 10 + ' Assignment 5 ' + '#' * 10 + '\n\n'

execfile('troels.thomsen.qvw203_5.py')

print '\n\n' + '#' * 10 + ' Assignment 6 ' + '#' * 10 + '\n\n'

execfile('troels.thomsen.qvw203_6.py')