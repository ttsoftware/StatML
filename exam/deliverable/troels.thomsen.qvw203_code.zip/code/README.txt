
Run "python troels.thomsen.qvw203.py"

Requires:
    python 2.7, matplotlib, numpy, scipy, and sklearn

Most plots (except for assignment 4 & 5) have been commented out in order to make it easier to discern the prints of the file.